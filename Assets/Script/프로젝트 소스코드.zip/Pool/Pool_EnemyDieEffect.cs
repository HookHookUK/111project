using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pool_EnemyDieEffect : ObjectPool<Effect_EnemyDie>
{

}
