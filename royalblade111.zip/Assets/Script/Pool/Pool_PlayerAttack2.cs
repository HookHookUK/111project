using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pool_PlayerAttack2 : ObjectPool<PlayerAttack2>
{
}
